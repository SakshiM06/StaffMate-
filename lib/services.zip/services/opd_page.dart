import 'package:flutter/material.dart';

class OPDPage extends StatelessWidget {
  const OPDPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "OPD Services",
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
    );
  }
}
